%d0=4 e d1=1 num matricola(7713114)
d1=1;
d0=4;
n=10*(d1+1)+d0;
A=diag(ones(1,n-1),1)+eye(n);
E=zeros(n,n);
E(n,1)=2^-n;
B=A+E;

%punto a
VA=eig(A);
VB=eig(B);

norm(B-A)/norm(A)
norm(VB-VA)/norm(VA)

%punto b
a=A'*A;
b=B'*B;
VA2=eig(a);
VB2=eig(b);
normBA2=norm(b-a)/norm(a)
normV2=norm(VB2-VA2)/norm(VA2)
