% punto a
edges=[
    1 2;
    1 3;
    1 5;
    1 6;
    1 7;
    1 8;
    2 10;
    3 10;
    4 5;
    4 5;
    4 11;
    5 8;
    6 7;
    8 9;
    10 11
];%scrivo tutte le connesioni tra i nodi
M=graph(edges(:,1),edges(:,2));% questa riga prende la lista degli archi e successivamente crea un grafo
A=adjacency(M);% qua creo la matrice di adiacenza
full(A)% rende la matrice creata nella riga prima leggibile         

%punto b

g=sum(A,1);
D=diag(g);
G=A*inv(D);
G=full(G);
G
[V,Lambda]=eig(G);%calcolo la decomposizione agli autovalori della matrice G
diag_lambda=diag(Lambda);%prende solo la diagonale di LAmbda e li mette in un vettore
diag_lambda %mando a schermo gli autovalori
V %mando a schermo gli autovettori 

%punto c

%verifica 1
ha_uno=any(abs(diag_lambda - 1) < 1e-12)%vedo se è presente un autovalore uguale a 1 (esce uno se è vero 0 altrimenti)
altri=abs(diag_lambda(abs(diag_lambda-1)>1e-12));
tutti_minori_di_uno=all(altri < 1)

%verifica 2

vettore=find(abs(diag_lambda-1)<1e-12);%trovo l'indice dell' autovalore che è uguale ad 1
x=V(:,vettore);
% controllo che tutte le componenti siano tra 0 e 1
autovettore_valido=all(x >= 0 & x <= 1)

%verifica 3

autovettori_non1=V(:, abs(diag_lambda-1)>1e-12);%selezionotutte le colonne i cui autovalori non sono 1
componenti_mist=all(any(autovettori_non1>0) & any(autovettori_non1<0))%qua invece verifico che ci siano sia valori positivi che negativi

