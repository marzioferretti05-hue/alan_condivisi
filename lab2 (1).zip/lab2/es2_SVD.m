n_values = [5 10 20 50];

for k=1:length(n_values)
    n=n_values(k);
    B=triu(-ones(n));%triu prende la parte superiore della matrice
    B=B+2*eye(n);
    sigma=svd(B);
    sigma_max=max(sigma);
    sigma_min=min(sigma);
    cond_2=sigma_max/sigma_min;% condizionamento in norma 2
    fprintf('n = %d\n',n)
    disp(sigma)%tutti i valori singolari

    %perturbazione
    B(n,1)=B(n,1)+(-2^(-2-n));
    lambda=eig(B);
    fprintf('n=%d\n',n); 
    disp(lambda); % autovalori della matrice perturbata

end
%ultimo punto da fare in relazione