%d0=4 e d1=1 num matricola(7713114)
d1=1;
d0=4;
m=10*(d0+1)+d1;
x=(1)/m;
% costruzione matrice A (mx3)
A=[ones(m,1) x' (x'.^2)];

% SVD di A
[U,S,V] = svd(A);
% SVD di A'
[Ut,St,Vt] = svd(A');
disp('Valori singolari di A:')
diag(S)
disp('Valori singolari di A^T:')
diag(St)

%per ora ho fatto soloo il primo punto del primo esercizio
%secondo punto dell'esercizio da fare nella relazione perchè è un
%confronto 

%---------------------------------------------------------------------

% immagine di A
QA=orth(A);

% calcolo vettori singolari sinistri 
r=rank(A);
UA=U(:,1:r);
%nella relazione devo confrontare i due risultati ottenuti (QA e UA)

% immagine di A^T
QAt=orth(A');

% Vettori singolari sinistri di A^T
rt=rank(A');
UAt= Ut(:,1:rt);
%nella relazione devo confrontare i due risultati ottenuti (QAt e UAt)

%---------------------------------------------------------------------

% nucleo di A
NA=null(A);

% vettori singolari destri 
r=rank(A);
VA=V(:,r+1:end);

disp('Confronto')
errore_NA=norm(NA-VA);
disp(errore_NA)

% nucleo di A^T
NAt = null(A');

% vettori singolari destri di A^T 
rt=rank(A');
VAt = Vt(:,rt+1:end);

disp('Confronto')
errore_NAt=norm(NAt-VAt);
disp(errore_NAt)