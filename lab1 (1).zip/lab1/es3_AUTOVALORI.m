A = [1 -1 2;-2 0 5;6 -3 6];
%punto a
kmax = 10; %numero massimo di iterazioni che ho deciso
x = [1;1;1];
for k=1:kmax
    x=A*x;
    x=x/norm(x);
end

y=[3;10;4];
for k=1:kmax
    y=A*y;
    y=y/norm(y);
end

% punto b 
var=8;% stima dell'autovalore dominante(shift)che scelgo io

z=[1;1;1];
for k=1:kmax
    z=(A-var*eye(3))\z;
    z=z/norm(z);
end
lambda_inv=z'*A*z; % autovalore approssimato
%mando a schermo i risultati che ho trovato
x
y
z
lambda_inv