% Costruzione di x e y
x=(1:m)'/m;
y=sin(x);

% Costruzione della matrice A
A=[ones(m,1),x,x.^2];

% SVD
[U,S,V]=svd(A,'econ');%uso econ per rendere la SVD compatta

% Soluzione ai minimi quadrati tramite SVD
c0=V*(S\(U'*y));

% decomposizione QR:

[Q,R]=qr(A,0);
b=Q'*y;
c1=R\b;

% equazioni normali
ATA=A'*A;
ATy=A'*y;

c2=ATA\ATy;

%comando Matlab c = A\y;
c3=A\y;

%confronto tra tutti i risultati ottenuti:
norm(c0-c1)
norm(c0-c2)
norm(c0-c3)